from game_details import battle
battle.game()
